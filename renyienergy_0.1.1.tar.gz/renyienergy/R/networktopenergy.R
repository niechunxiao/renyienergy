#' The topological energy of the network.
#'
#' @param t Adjacency matrix
#' @param k The parameter of the threshold values.
#'
#' @return A list that includes topological energy.
#' @export
#'
#' @examples tope=networktopenergy(t,2)
networktopenergy<-function(t,k){
  #This function is used to calculate the topological energy of the network.
  d=resistancedist(t)
  ordd=ordercomplex(d,k)
  dt=ordd$t
  Lab=ordd$Lab
  thrvalue=ordd$thrvalue
  n=dim(dt)
  e=matrix(data=0,nrow=n[3],ncol = 1)
  for (i in 1:n[3]){
    e[i]=graphenergy(dt[,,i])
  }
  tope=mean(e)
  output=list(tope=tope,Lab=Lab,e=e,thrvalue=thrvalue)
  return(output)
}
