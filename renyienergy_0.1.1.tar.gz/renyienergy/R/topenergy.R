#' The topological energy of the distance matrix.
#'
#' @param d Distance matrix
#' @param k The parameter of the threshold values.
#'
#' @return A list that includes topological energy.
#' @export
#'
#' @examples tope=networktopenergy(d,10)
topenergy<-function(d,k){
  #This function is used to calculate the topological energy of the distance matrix.
  ordd=ordercomplex(d,k)
  dt=ordd$t
  Lab=ordd$Lab
  n=dim(dt)
  e=matrix(data=0,nrow=n[3],ncol = 1)
  for (i in 1:n[3]){
    e[i]=graphenergy(dt[,,i])
  }
  tope=mean(e)
  output=list(tope=tope,Lab=Lab,e=e)
  return(output)
}
