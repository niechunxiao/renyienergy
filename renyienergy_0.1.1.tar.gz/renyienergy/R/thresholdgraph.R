#' Threshold graph
#' Elements in the distance matrix that are less than or equal to the threshold are converted to 1.
#' @param d Distance matrix
#' @param th Threshold
#'
#' @return Adjacency matrix
#' @export
#'
#' @examples t=thresholdgraph(d,0.2)
thresholdgraph<-function(d,th){
  #threshold graph
  adjd=ifelse(d<=th,1,0)
  n=dim(d)
  for (i in 1:n[2]){
    adjd[i,i]=0
  }
  return(adjd)
}
