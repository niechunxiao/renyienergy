#' The resistance distance between a pair of nodes.
#'
#' @param H Generalized inverse matrix of Laplace matrix.
#' @param n The number of nodes.
#' @param i node i
#' @param j node j
#'
#' @return The value of the resistance distance.
#'
#'
#' @examples
resistancedist01<-function(H,n,i,j){
  #This function is called by the function resistancedist.
  eij=matrix(data=0,nrow=n,ncol = 1)
  eij[i]=1
  eij[j]=-1
  eij1=t(eij)
  rij=eij1%*%H%*%eij
  return(rij)
}
