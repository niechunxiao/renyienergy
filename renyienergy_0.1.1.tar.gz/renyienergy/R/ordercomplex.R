#' Order complex
#'
#' @param d Distance matrix
#' @param k The parameter of the threshold values.
#'
#' @return Order complex
#' @export
#'
#' @examples ord=ordercomplex(d,1)
ordercomplex<-function(d,k){
  #This function is used to generate the order complex.
  #The input d is the distance matrix, while k is the parameter used to calculate the graph sequence.
  dup=round(d,10)
  dup[!upper.tri(dup,diag = FALSE)]<-0
  dup1=c(dup)
  dup2=sort(unique(dup1))
  dup3=dup2[-1]
  #Remove 0
  m=length(dup3)
  n=dim(d)
  n1=n[1]
  d1=dup+t(dup)
  #These lines of code are used to keep d a strictly symmetric matrix.
  s=seq(from = 1, to = m,by = k)
  ns=length(s)
  t = array(0, dim = c(n[1],n[2],ns))
  Lab=array(0, dim = c(1,ns))
  for (i in 1:ns){
    t[,,i]=  thresholdgraph(d1,dup3[s[i]])
    Lab[i]=i/ns
  }
  output<-list(t=t,Lab=Lab,thrvalue=dup3)
  return(output)
}
