#' The topological Laplacian energy of the distance matrix.
#'
#' @param d Distance matrix
#' @param k The parameter of the threshold values.
#'
#' @return A list that includes topological normalized Laplacian energy.
#' @export
#'
#' @examples tope=toplapenergy(d,10)
toplapenergy<-function(d,k){
  #This function is used to calculate the topological Laplacian energy of the distance matrix.
  ordd=ordercomplex(d,k)
  dt=ordd$t
  Lab=ordd$Lab
  n=dim(dt)
  Lape=matrix(data=0,nrow=n[3],ncol = 1)
  for (i in 1:n[3]){
    Lape[i]=lapgraphenergy(dt[,,i])
  }
  Laptope=mean(Lape)
  output=list(Laptope=Laptope,Lab=Lab,Lape=Lape)
  return(output)
}
