#' This function generates a random graph and calculates the topological energy.
#' The resulting random graph has the same degree sequence as the original network.
#' @param adj Adjacency matrix
#' @param k The parameter of the threshold values.
#'
#' @return A list that includes topological energy.
#' @export
#'
#' @examples tope=randomgraphte(t,1)
randomgraphtope<-function(adj,k){
  library(igraph)
  degadj=colSums(adj,dims=1)
  randg=sample_degseq(degadj, in.deg = NULL, method = "simple.no.multiple")
  randadj=as.matrix(get.adjacency(randg))
  d=resistancedist(randadj)
  ordd=ordercomplex(d,k)
  dt=ordd$t
  Lab=ordd$Lab
  n=dim(dt)
  e=matrix(data=0,nrow=n[3],ncol = 1)
  for (i in 1:n[3]){
    e[i]=graphenergy(dt[,,i])
  }
  tope=mean(e)
  output=list(tope=tope,Lab=Lab,e=e,randadj=randadj)
  return(output)
}
