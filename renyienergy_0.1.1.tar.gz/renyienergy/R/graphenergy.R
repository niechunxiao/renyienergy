#' Graph energy
#'
#' @param t Adjacency matrix
#'
#' @return The energy of the graph.
#' @export
#'
#' @examples e=graphenergy(adj)
graphenergy<-function(t){
  #This function is used to calculate graph energy.
  e=eigen(t)
  ev= e$values
  ev1=abs(ev)
  et=sum(ev1)
  return(et)
}
