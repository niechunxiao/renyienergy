#' Global Renyi index
#'
#' @param d Distance matrix
#' @param q The parameter of the Renyi index.
#' @param p Threshold ratio.
#' @param p0 The parameter of the threshold values.
#'
#' @return GRI value
#' @export
#'
#' @examples gri=globalrenyi(d,2,c(0.1,0.25),0.01)
globalrenyi<-function(d,q,p,p0){
  #This function calculates the global Renyi index.
  nd=dim(d)
  ds1=sort(unique(c(d)))
  ds=ds1[-1]
  n=length(ds)
  L=floor(n*seq(from=p[1],to=p[2],by=p0))
  th=ds[L]
  n1=length(th)
  t=array(data=0,dim=c(nd[1],nd[2],n1))
  for(i in 1:n1){
    t[,,i]=thresholdgraph(d,th[i])
  }
  R=matrix(data=0,nrow = n1,ncol = 1)
  for (i in 1:n1){
    R[i]=networkrenyi(t[,,i],q)
  }
  thr=cbind(th,R)
  m=lm(R~th+I(th^2)+I(th^3))
  coe=m$coefficients
  f<-function(x)coe[1]+coe[2]*x+coe[3]*x^2+coe[4]*x^3
  GRI1=integrate(f,thr[1],thr[n1])$value
  GRI=GRI1/(thr[n1]-thr[1])
  output=list(GRI=GRI,coe=coe,thr=thr)
  return(output)
}
