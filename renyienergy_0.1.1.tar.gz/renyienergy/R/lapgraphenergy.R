#' The Laplacian energy
#'
#' @param t Adjacency matrix
#'
#' @return The Laplacian energy of the graph.
#' @export
#'
#' @examples e=lapgraphenergy(adj)
lapgraphenergy<-function(t){
  #This function is used to calculate graph Laplacian energy.
  d<-apply(t,1,sum)#计算节点的度
  n1=dim(t)
  n=n1[2]
  Ld<-matrix(0,n,n)#计算拉普拉斯矩阵
  for(i in 1:n){
     Ld[i,i]=d[i]
  }
  L=Ld-t
  e=eigen(L)
  ev= e$values
  ev1=abs(ev-sum(t)/n1)
  Lape=sum(ev1)
  return(Lape)
}
