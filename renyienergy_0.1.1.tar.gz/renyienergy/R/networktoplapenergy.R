#' The topological Laplacian energy of the network.
#'
#' @param t Adjacency matrix
#' @param k The parameter of the threshold values.
#'
#' @return A list that includes topological Laplacian energy.
#' @export
#'
#' @examples tope=networktoplapenergy(t,2)
networktoplapenergy<-function(t,k){
  #This function is used to calculate the normalized Laplacian topological energy of the network.
  d=resistancedist(t)
  ordd=ordercomplex(d,k)
  dt=ordd$t
  Lab=ordd$Lab
  thrvalue=ordd$thrvalue
  n=dim(dt)
  lape=matrix(data=0,nrow=n[3],ncol = 1)
  for (i in 1:n[3]){
    lape[i]=lapgraphenergy(dt[,,i])
  }
  toplape=mean(lape)
  output=list(toplape=toplape,Lab=Lab,lape=lape,thrvalue=thrvalue)
  return(output)
}
