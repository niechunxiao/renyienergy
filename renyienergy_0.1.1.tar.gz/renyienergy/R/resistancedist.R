#' The resistance distance matrix of the network.
#'
#' @param t Adjacency matrix
#'
#' @return Resistance distance matrix
#' @export
#'
#' @examples resd=resistancedist(adj)
resistancedist<-function(t){
  library(MASS)
  #This function calculates the resistance distance matrix of a network.
  deg=rowSums(t)
  n=dim(t)
  tdeg=matrix(data=0,nrow = n[1],ncol = n[2])
  diag(tdeg)=deg
  L=tdeg-t
  #Laplace matrix
  H=ginv(L)
  d1=matrix(data=0,nrow = n[1],ncol=n[2])
  for(i in 1:n[1]){
    for(j in 1:n[1]){
      if (i<j){d1[i,j]=resistancedist01(H,n[1],i,j)
      }
    }
  }
  d=d1+t(d1)
  return(d)
}
