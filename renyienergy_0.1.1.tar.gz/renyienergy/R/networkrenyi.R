#' The Renyi index of the network.
#'
#' @param t Adjacency matrix
#' @param q Parameter of the Renyi index.
#'
#' @return Renyi index value
#' @export
#'
#' @examples r2=networkrenyi(adj,2)
networkrenyi<-function(t,q){
  #This function calculates the Renyi index of a network.
  n=dim(t)
  dt=rowSums(t)
  md=mean(dt)
  dtm=dt/md
  if(q!=1){
    R=1-((1/n[1])*sum(dtm^q))^(1/(1-q))
  }else{
    R=1-exp((1/(1-n[1]))*(sum(dtm*log(dtm))))
  }
  return(R)
}
